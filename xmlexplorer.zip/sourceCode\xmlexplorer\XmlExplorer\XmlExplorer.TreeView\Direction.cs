﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XmlExplorer.TreeView
{
	public enum Direction
	{
		Up,
		Down,
	}
}
