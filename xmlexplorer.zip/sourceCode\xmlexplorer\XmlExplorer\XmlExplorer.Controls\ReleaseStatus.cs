﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XmlExplorer.Controls
{
    public enum ReleaseStatus
    {
        Alpha = 0,
        Beta = 1,
        Stable = 2,
    }
}
